<template>
  <div>
    <navbar />
    <div class="page">
      <sidebarpage />
      <nuxt />
    </div>
  </div>
</template>

<script>
import navbar from '~/components/navbar.vue'
import sidebarpage from '~/pages/content/Sidebarpage.vue'

export default {
  layout: 'content',
  name: 'Content',
  components: {
    navbar, sidebarpage
  }
}
</script>

<style scoped>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap');
  html body {
    background-color: #f7f9fa!important;
  }
  nav {
    margin-bottom: 40px;
  }
  .page {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    justify-content: center;
    margin: 0 auto;
    width: 100%;
    max-width: 1400px;
    padding: 0 15px 20px;
    font-family: 'Montserrat', sans-serif;
  }
  .sidebarpage {
    width: 30%;
  }
  .content {
    width: 70%;
    padding: 17px 20px 20px 20px;
    background-color: #f8f8f8;
    text-align: left
  }
</style>
