<template>
  <div class="animationslayout">
    <navbar />
    <div class="container">
      <animationssidebar />
      <nuxt />
    </div>
  </div>
</template>

<script>
import navbar from '~/components/navbar.vue'
import animationssidebar from '~/pages/animations/animationssidebar.vue'
export default {
  components: {
    navbar, animationssidebar
  }
}
</script>

<style scoped>
nav {
  margin-bottom: 40px;
}
.animationslayout-bg {
  background-color: #f1f3f4;
}
.animationslayout {
  background: url(https://ssl.gstatic.com/bfe/images/dashboard/tasklist-l.png) no-repeat left top,
  url(https://ssl.gstatic.com/bfe/images/dashboard/tasklist-r.png) no-repeat right top;
  background-size: 25%;
}
.animationslayout > .container {
  display: flex;
  flex-direction: row;
  flex-wrap: nowrap;
  justify-content: flex-start;
}
.animationssidebar {
  width: 30%;
}
</style>
