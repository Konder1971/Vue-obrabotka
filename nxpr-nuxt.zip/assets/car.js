import Vue from 'vue'
import Car from '~/assets/Car.vue'
Vue.component('app-car', Car)
export const eventEmitter = new Vue()
