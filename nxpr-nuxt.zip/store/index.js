import Vuex from 'vuex'

const createStore = () => {
  return new Vuex.Store({
    state: () => ({
      technologies: [
        {
          id: 1,
          name: 'Vue.js',
          descripnions: 'Vue Super project'
        },
        {
          id: 2,
          name: 'Nuxt.js',
          descripnions: 'Nuxt Super developer'
        },
        {
          id: 3,
          name: 'HTML5/CSS3',
          descripnions: 'New progressive razmetka'
        }
      ]
    })
  })
}

export default createStore

/*
import Car from '~/assets/Car.vue'
Vue.component('app-car', Car)
export const eventEmitter = new Vue()
*/
