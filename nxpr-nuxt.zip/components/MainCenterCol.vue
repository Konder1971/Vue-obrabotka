<template>
  <div class="maincentercol">
    <h3>Main Center Col</h3>
    <p>
      Lorem, ipsum dolor sit amet consectetur adipisicing elit. Pariatur minus assumenda architecto. Quis, magnam culpa. Provident harum eligendi, reiciendis accusamus hic mollitia earum quas explicabo repellendus reprehenderit! Perferendis, nulla facilis?
    </p>
  </div>
</template>

<script>
export default {
  name: 'MainCenterCol'
}
</script>

<style>
</style>
