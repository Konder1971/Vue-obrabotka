<template>
  <div>
    <ul>
      <TodoItem
        v-for="(todo, i) in todos"
        :key="todo.id"
        :index="i"
        :todo="todo"
        @remove-todo="removeTodo"
      />
    </ul>
  </div>
</template>

<script>
import TodoItem from '~/components/TodoItem'
export default {
  name: 'TodoList',
  components: {
    TodoItem
  },
  props: ['todos'],
  methods: {
    removeTodo (id) {
      this.$emit('remove-todo', id)
    }
  }
}
</script>

<style scoped>
ul {
  margin: 0 auto;
  max-width: 600px;
  padding: 0;
  list-style: none;
}
</style>
