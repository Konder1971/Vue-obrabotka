<template>
  <div class="mainleftcol">
    <h3>Main Left Col</h3>
    <p>
      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Sapiente mollitia ullam, odio eveniet expedita repellendus qui impedit commodi esse quia!
    </p>
    <div>
      <nuxt-link to="/">
        Home
      </nuxt-link>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MainLeftCol'
}
</script>
