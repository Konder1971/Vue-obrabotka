<template>
  <div class="container">
    <h1>Animations Index Page</h1>
    <hr>

    <div id="flip-list-demo" class="demo">
      <button @:click="shuffle">
        Перемешать
      </button>
      <transition-group name="flip-list" tag="ul">
        <li v-for="item in items" :key="item">
          {{ item }}
        </li>
      </transition-group>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      items: [1, 2, 3, 4, 5, 6, 7, 8, 9]
    }
  },
  mounted () {
    const recaptchaScript = document.createElement('script')
    recaptchaScript.setAttribute('src', 'https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.14.1/lodash.min.js')
    document.head.appendChild(recaptchaScript)
  },
  methods: {
    shuffle () {
      // this.items = _.shuffle(this.items)
    }
  }
}
</script>

<style scoped>
hr {
  margin-bottom: 10px;
}
button {
  color: #fff;
  background-color: darkgreen;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: inline-block;
  padding: 6px 14px;
  margin: 0 10px 10px 0;
  font-size: 16px;
  font-weight: 600;
  outline: none;
}
button:hover,
button.active {
  background-color: #850000;
}
.animeBlock {
  border-bottom: 1px solid #222;
  margin-bottom: 10px;
  padding-bottom: 10px;
}

.flip-list-move {
  transition: transform 1s;
}
</style>
