<template>
  <div class="technologies">
    <h1>My Technologies</h1>
    <p>https://www.youtube.com/watch?v=qaR4km_N7xw</p>
    <div v-for="tech in technologies" :key="tech.id" class="techno">
      <h3>{{ tech.name }}</h3>
      <p>{{ tech.descripnions }}</p>
      <nuxt-link :to="{path:'/technologies/'+tech.id}">
        See details
      </nuxt-link>
    </div>
  </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
  computed: mapState(['technologies'])
}
</script>

<style>
.technologies h1 {
  margin: 0;
}
.technologies hr {
  border-top: 1px solid rgba(0, 0, 0, 1);
  margin: 20px 0;
}
.techno * {
  margin: 0;
  padding: 0;
}
.techno {
  border: 2px solid #28a745;
  padding: 10px 15px;
  margin-bottom: 20px
}
</style>
