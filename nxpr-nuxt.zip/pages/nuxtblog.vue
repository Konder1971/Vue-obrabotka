<template>
  <div class="blog">
    <div class="blogcontent">
      <router-view />
    </div>
    <blogsidebar />
  </div>
</template>

<script>
import blogsidebar from '~/pages/nuxtblog/BlogSidebar.vue'

export default {
  name: 'Nuxtblog',
  components: {
    blogsidebar
  }
}
</script>

<style scoped>
  .blog {
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    justify-content: center;
    margin: 50px 0;
    text-align: left;
  }
  .blogsidebar {
    width: 30%;
  }
  .blogcontent {
    width: 70%;
    padding: 20px 30px;
    background-color: #F0A829;
    color: #000;
  }

  .blog h1,
  .blog h2 {
    color: #42b983;
    font-size: 30px;
    margin-bottom: 15px;
  }
  .blog h1 {
    color: #116149;
  }
  .blog p {
    margin-bottom: 15px;
    color: #000;
  }
  .blog input {
    border: 0;
    height: 35px;
    width: 100%;
    padding: 5px 10px;
    font-size: 16px
  }
  .blog button {
    background-color: #35495e;
    color: #fff;
    font-size: 18px;
    padding: 10px 15px;
    cursor: pointer;
    border: none;
    border-radius: 4px;
  }
  .blog button:hover {
    background-color: #880000;
  }
  hr {
    display: block;
    height: 1px;
    border: 0;
    border-top: 1px solid #000;
    margin: 10px 0;
    padding: 0;
  }
</style>
