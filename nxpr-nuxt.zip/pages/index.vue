<template>
  <div>
    <h3>{{ data }}</h3>
    <h3 v-if="Math.random() > 0.5">
      Случайное число > 0.5
    </h3>
    <h3 v-else>
      Меньше-равно 0.5
    </h3>
    <h1>
      My Nuxt.js Project
    </h1>
  </div>
</template>

<script>
export default {
  data () {
    return {
      data: new Date().toLocaleString()
    }
  },
  mounted () {
    setInterval(() => {
      this.updateDate()
    }, 1000)
  },
  methods: {
    updateDate () {
      this.data = new Date().toLocaleString()
    }
  }
}
</script>

<style scoped>
</style>
