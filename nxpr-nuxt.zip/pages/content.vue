<template>
  <nuxt />
</template>

<script>
export default {
  layout: 'content'
}
</script>
