<template>
  <div class="content">
    <h1>Блог - Работа со списками:</h1>
    <hr>

    <ul>
      <li
        v-for="person in people"
        :key="person"
      >
        {{ person }}
      </li>
    </ul>

    <ul>
      <li
        v-for="(person, index) in people"
        :key="index"
      >
        {{ index +1 }} {{ person }}
      </li>
    </ul>

    <ul>
      <li
        v-for="(person, index) in staff"
        :key="person"
      >
        {{ index +1 }}. <b>{{ person.name }} :</b> {{ person.age }} age
      </li>
      <!-- вместо in мщжно использовать of -->
    </ul>

    <ul class="nambers">
      <span>Вывод списка<br>последовательности чисел<br>от 1 до 10 (или другого)</span>
      <li
        v-for="num of 10"
        :key="num"
      >
        {{ num }};
      </li>
    </ul>

    <hr>

    <h3>Работа с объектом и value, key, index</h3>
    <ul>
      <li
        v-for="(value, key, index) of pesonMax"
        :key="index"
      >
        {{ index + 1 }}. <b>{{ key }}</b>, {{ value }}
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'Rabotasospiskomblog',
  data () {
    return {
      people: [
        'Vlad',
        'Vedot',
        'Patrick',
        'Sveta',
        'Klava'
      ],
      staff: [
        { name: 'Ivan', age: '24' },
        { name: 'Joe', age: '18' },
        { name: 'Semen', age: '37' },
        { name: 'Alex', age: '32' },
        { name: 'Marfa', age: '26' }
      ],
      pesonMax: {
        name: 'Max',
        age: 34,
        jpb: 'Frontend'
      }
    }
  }
}
</script>

<style scoped>
  ul {
    display: inline-block;
    list-style: none;
    margin: 15px 30px 25px 0;
    padding: 0 30px 0 0 ;
    border-right: 1px solid #fff;
    vertical-align: top;
  }
  .nambers span {
    display: block;
  }
  .nambers li {
    display: inline-block;
  }
</style>
