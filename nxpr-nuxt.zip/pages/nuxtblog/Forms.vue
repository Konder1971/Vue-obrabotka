<template>
  <div class="content">
    <input
      v-model="vpishi"
      type="text"
      placeholder="впиши"
    >
    <button @click="dobav">
      Добавить
    </button>
    <ul>
      <li
        v-for="item in items"
        :key="item"
      >
        {{ item }}
      </li>
    </ul>
    <hr>

    <br>
    <!--
    https://www.youtube.com/watch?reload=9&v=b7r6JlLvF0Q&list=PLu_62Q68DvTrWAR_3-iOfIdbqKU912i3z&index=2
    https://openlibrary.org/dev/docs/json_api
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    -->
    <form>
      <div class="well">
        <div class="form-group">
          <label for="firstname">First name</label>
          <input
            id="firstname"
            v-model="formData.firstname"
            type="text"
            placeholder="firstname"
          >
        </div>
        <div class="form-group">
          <label for="lastname">lastname</label>
          <input
            id="lastname"
            v-model="formData.lastname"
            type="text"
            placeholder="lastname"
          >
        </div>
        <div class="form-group">
          <label for="url">Blog</label>
          <input
            id="url"
            v-model="formData.url"
            type="text"
            placeholder="url"
          >
        </div>
        <div class="form-group">
          <label for="badge">Personal badge (html)</label>
          <textarea
            id="badge"
            v-model="formData.badge"
            cols="30"
            rows="10"
            placeholder="Вставь HTML код"
          />
        </div>
        <div class="form-group">
          <label for="book">Favorite book ISBN (like 0201558025) - не работает</label>
          <input
            id="book"
            v-model="formData.bookisbn"
            type="text"
            placeholder="0789312239"
          >
        </div>
        <div class="form-group">
          <label for="techno">Technologies</label>
          <input
            id="techno"
            v-model="formData.technologies"
            type="text"
            placeholder="techno"
          >
          <button
            type="submit"
            @click.prevent="submit"
          >
            Submit
          </button>
        </div>
      </div>
    </form>

    <div
      v-if="showDetails"
      class="well"
    >
      <h3>Dear {{ fullname }} !</h3>
      <p>
        Me blog is <a
          :href="formData.url"
          target="_blank"
        >here</a>
      </p>
      <div>
        <h4>My favorite bood isbn '{{ book.title }}'</h4>
        <img :src="book.url">
      </div>
      <p>
        My technologies:
        <ul>
          <li
            v-for="tech in mytechnologies"
            :key="tech.id"
          >
            {{ tech }}
          </li>
        </ul>
      </p>
    </div>

    <div
      v-else
      class="well"
    >
      Please submit the form
    </div>
  </div>
</template>

<script>
export default {
  name: 'Forms',
  data () {
    return {
      vpishi: '',
      items: [],

      formData: {
        firstname: '',
        lastname: '',
        url: 'http://',
        badge: '',
        bookisbn: '',
        technologies: ''
      },

      showDetails: false,

      book: {
        title: '',
        url: ''
      }

    }
  },
  computed: {
    fullname () {
      return this.formData.firstname + ' ' + this.formData.lastname
    },
    mytechnologies () {
      return this.formData.technologies.split(',')
    }
  },
  watch: {

  },
  methods: {
    dobav () {
      this.items.push(this.vpishi)
      this.vpishi = ''
    },
    submit () {
      this.showDetails = true
    }
  }
}
</script>

<style scoped>
  button {
    color: #fff;
    background-color: darkgreen;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    display: inline-block;
    padding: 8px 12px 10px;
    margin: 15px 15px 0 0;
    font-size: 18px;
    font-weight: 600;
  }
  button:hover {
    background-color: #850000;
  }
  input {
    padding: 5px 10px 7px;
    font-size: 18px;
    margin-right: 10px
  }

  .form-group {
    margin-bottom: 15px;
  }
  label {
    display: block;
    margin-bottom: 4px;
  }
  .well input,
  .well textarea {
    width: 100%;
    display: block;
    margin: 0;
  }
</style>
