<template>
  <div class="content">
    <h1>Передача HTML компоненту, slot</h1><hr>
    <h3>{{ slp }}</h3>
    <forslot />
  </div>
</template>

<script>
import forslot from '~/pages/nuxtblog/forslot.vue'
export default {
  components: {
    forslot
  },
  data () {
    return {
      slp: 'Slot 1 Variant'
    }
  }
}
</script>

<style scoped>
</style>
