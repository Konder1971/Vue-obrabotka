<template>
  <v-app app>
    <h1>Title</h1>
    <p>https://www.youtube.com/watch?v=CpUiV26qrJU</p>
    <p>https://socket.io/</p>
    <hr />
  </v-app>
</template>

<script>
export default {}
</script>
