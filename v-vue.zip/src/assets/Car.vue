<template>
  <div class="container car">
    <h4>Передача параметров компоненту, и от дочернего компонента</h4>
    <h5>{{ carName }} | {{ reversName }}</h5>
    <p>Car Name: {{ carName }}</p>
    <p>Car Year: {{ carYear }}</p>
    <button
      class="btn"
      @click="changeName"
    >
      Change name
    </button>
  </div>
</template>

<script>
export default {
  // props: ['carName', 'carYear'],
  props: {
    carName: String,
    carYear: Number
  },
  methods: {
    changeName() {
      this.carName = 'Mazda'
      this.$emit('nameCanged', this.carName)
    }
  },
  computed: {
    reversName() {
      return this.carName
        .split('')
        .reverse()
        .join('')
    }
  }
}
</script>

<style scoped>
.car {
  border: 2px solid darkgreen;
  border-radius: 10px;
  padding: 20px 20px;
  margin: 10px auto 40px;
  text-align: left;
}
h4 {
  color: darkgreen;
  margin-bottom: 10px;
}
h5 {
  color: #222;
  margin-bottom: 10px;
}
button {
  margin: 10px 10px 0 0;
}
</style>