<template>
  <div class="home">
    <h3>{{ data }}</h3>
    <hr>
    <img
      class="logo"
      alt="Vue logo"
      src="../assets/logo.png"
    >

    <HelloWorld msg="Welcome to Your Vue.js App" />
  </div>
</template>

<script>
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Home',
  components: {
    HelloWorld
  },
  data() {
    return {
      data: new Date().toLocaleString()
    }
  },
  methods: {
    updateDate() {
      this.data = new Date().toLocaleString()
    }
  },
  mounted() {
    setInterval(() => {
      this.updateDate();
    }, 1000);
  }
}

</script>

<style scoped>
.logo {
  width: 80px;
}
p{
  margin: 20px 0;
}
hr {
  margin: 10px 0;
}
</style>
