<template>
  <div class="page3coll container-fluid">
    <MainContainer msg-h1="Title H1 Page" />
    <hr>
    <h4>Parent: {{ carName }}</h4>
    <app-car 
      :car-name="carName" 
      :car-year="carYear"
      @nameCanged="carName = $event"
    />
  </div>
</template>

<script>
import MainContainer from "@/components/MainContainer.vue";

export default {
  name: "Page3coll",
  data() {
    return {
      carName: 'Ford',
      carYear: 2018
    }
  },
  components: {
    MainContainer
  }
};
</script>

<style scoped>
</style>