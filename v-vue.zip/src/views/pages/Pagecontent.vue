<template>
  <div class="content">
    <h1>
      Page content
    </h1>
    <hr>

    <span class="udalit">
      Убрать через добавления style="display:none"
    </span><br>
    <button @click="ud">
      Кликай
    </button>
    <hr>
  </div>
</template>

<script>
export default {
  name: "Pagecontent",

  data() {
    return {};
  },

  methods: {
    ud() {
      document.querySelector('.udalit').style.display = 'none'
    }
  },

  computed: {},
  watch: {}
  
};
</script>

<style scoped>
button {
  color: #fff;
  background-color: darkgreen;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: inline-block;
  padding: 8px 12px 10px;
  margin: 15px 15px 0 0;
  font-size: 18px;
  font-weight: 600;
}
button:hover {
  background-color: #850000;
}
</style>