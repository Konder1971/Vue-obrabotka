<template>
  <div class="content">
    <h1>Варианты меню</h1>
    <hr>
    
    <ul>
      <li
        @click="activate(1)"
        :class="{ active : active_el == 1 }"
      >
        Link 1
      </li>
      <li
        @click="activate(2)"
        :class="{ active : active_el == 2 }"
      >
        Link 2
      </li>
      <li
        @click="activate(3)"
        :class="{ active : active_el == 3 }"
      >
        Link 3
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "Variantmenu",
  data() {
    return {
      active_el: 0
    }
  },
  methods: {
    activate: function(el) {
      this.active_el = el;
    }
  }
};
</script>

<style scoped>
ul > li {
  color: darkgreen;
}
ul > li:hover {
  cursor: pointer;
  text-decoration: underline;
}
.active {
  color: #850000;
}
</style>