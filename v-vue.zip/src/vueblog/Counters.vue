<template>
  <div class="content">
    <h1>Счётчики</h1>
    <hr>

    <p>
      <a
        target="_blank"
        href="https://www.youtube.com/watch?v=LeqSTpqCOMk&list=PLLvTAhHe8AYCf1RDc2l2ZWriPfMf-yZel&index=27"
      >видео для просмотра</a>
    </p>

    <Counterblock
      v-for="n in 3"
      :key="n"
    />

    <div class="counterblock">
      <p>{{ counterTitle }} = {{ counter1 }} | {{ counter2 }}</p>
      <p>Результат: {{ resultcounter }}</p>
      <p>
        <button @click="counterPlus(4, 'Увеличен на 4', $event)">
          Увеличить на + 4
        </button>
        <button @click="counterPlus(10, 'Увеличен на 10', $event)">
          Увеличить на + 10
        </button>
        <button @click="counterMinus(3, 'Уменьшен на 3', $event)">
          Уменьшить на - 3
        </button>
        <button @click="counterReset">
          Сбросить на 0
        </button>
      </p>
      <p>
        <button @mouseover="counter2++">
          Add Counter2 Hover
        </button>
      </p>
    </div>
  </div>
</template>

<script>
import Counterblock from "@/components/Counterblock.vue";
export default {
  name: "Counters",
  components: {
    Counterblock
  },
  data() {
    return {
      counterTitle: "Счетчик",
      counter1: 0,
      counter2: 0
    };
  },
  methods: {
    counterPlus: function(num, str, event) {
      this.counter1 += num;
      this.counterTitle = str;
      if (num === 4) {
        event.target.style.color = "blue";
      } else if (num === 10) {
        event.target.style.color = "red";
      }
    },
    counterMinus: function(num, str, event) {
      this.counter1 -= num;
      this.counterTitle = str;
      if (num === 3) {
        event.target.style.color = "silver";
      }
    },
    counterReset() {
      this.counter1 = 0;
      event.target.style.color = "#42b983";
      this.counterTitle = "Счетчик";
    }
  },
  computed: {
    resultcounter: function() {
      return this.counter1 > 6 ? "Больше 6" : "Меньше 6";
    }
  }
};
</script>

<style>
h1 {
  color: #333;
}
p {
  color: #333;
  font-size: 18px;
  font-weight: 600;
  margin: 0 0 10px 0;
}
a {
  color: darkgreen;
}
a:hover {
  color: #850000;
  text-decoration: none;
}
.counterblock {
  border: 2px solid #333;
  border-radius: 4px;
  padding: 15px 20px 10px 20px;
  margin: 0 0 20px 0;
}
button {
  color: #fff;
  background-color: darkgreen;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  display: inline-block;
  padding: 10px 14px 12px;
  margin: 0 10px 10px 0;
  font-size: 18px;
  font-weight: 600;
}
button:hover {
  background-color: #850000;
}
</style>