import '@babel/polyfill'
import 'mutationobserver-shim'
import Vue from 'vue'
import './plugins/bootstrap-vue'
import App from './App.vue'
import './registerServiceWorker'
import router from './router'
import store from './store'
import './css/style.css'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import Car from './assets/Car.vue'

Vue.config.productionTip = false

Vue.component('app-car', Car)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
