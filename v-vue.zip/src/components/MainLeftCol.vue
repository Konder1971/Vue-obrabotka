<template>
  <div class="mainleftcol">
    <h3>MainLeftCol</h3>
  </div>
</template>

<script>
export default {
  name: "MainLeftCol",
};
</script>

<style scoped>

</style>