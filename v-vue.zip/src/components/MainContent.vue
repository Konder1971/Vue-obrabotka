<template>
  <div class="maincontent">
    <h2>{{ msgH2 }}</h2>
    <MainContentBox />
  </div>
</template>

<script>
import MainContentBox from "@/components/MainContentBox.vue";

export default {
  name: "MainContent",
  props: {
    msgH2: String
  },
  components: {
    MainContentBox
  }
};
</script>

<style scoped>
</style>