<template>
  <div class="maincentercol">
    <h3>MainCenterCol</h3>
  </div>
</template>

<script>
export default {
  name: "MainCenterCol",
};
</script>

<style scoped>
</style>