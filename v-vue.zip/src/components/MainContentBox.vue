<template>
  <div class="maincontantbox">
    <MainLeftCol />
    <MainCenterCol />
    <MainRightCol />
  </div>
</template>

<script>
import MainLeftCol from "@/components/MainLeftCol.vue";
import MainCenterCol from "@/components/MainCenterCol.vue";
import MainRightCol from "@/components/MainRightCol.vue";

export default {
  name: "MainContentBox",
  components: {
    MainLeftCol,
    MainCenterCol,
    MainRightCol
  }
};
</script>

<style scoped>
.maincontantbox {
	display: flex;
	flex-direction: row;
	flex-wrap: nowrap;
	justify-content: center;
  text-align: left;
}
.maincontantbox > div {
  margin: 0 15px;
}
</style>