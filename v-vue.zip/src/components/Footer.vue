<template>
  <div class="footer">
    <h3>Footer Block</h3>
    <img
      alt="Vue logo"
      src="@/assets/logo.png"
    >
  </div>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style scoped>
.footer {
    background-color: #850000;
    color: #fff;
    padding: 30px;
    text-align: center;
}
.footer img {
  width: 60px;
}
</style>