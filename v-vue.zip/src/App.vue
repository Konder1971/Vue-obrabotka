<template>
  <div id="app">
    <Top />
    <Top3 />
    <div id="nav">
      <router-link to="/">
        Home
      </router-link>
      <router-link to="/vueblog">
        Vue Blog
      </router-link>
      <router-link to="/page">
        Page
      </router-link>
      <router-link to="/recepts">
        Recepts
      </router-link>
      <router-link to="/page3coll">
        Page3coll
      </router-link>
      <router-link to="/jscollection">
        JsСollection
      </router-link>
      <router-link to="/about">
        About
      </router-link>
    </div>
    <router-view />
    <Footer />
  </div>
</template>

<script>
import Top from '@/components/Top.vue'
import Top3 from '@/components/Top3.vue'
import Footer from '@/components/Footer.vue'
export default {
  components: {
   Top, Top3, Footer
  }
}
</script>

<style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap');
#app {
  font-family: 'Montserrat', sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {  
  display: flex;
	flex-direction: row;
	flex-wrap: wrap;
	justify-content: center;
	align-items: center;
	align-content: center;
  padding: 15px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
  text-decoration: none;
  padding: 10px;
}
#nav a:hover,
#nav a.router-link-exact-active {
  color:crimson;
}

hr {
  margin: 10px 0;
}
</style>
