<template>
  <div class="content">
    <h1>Фильтры</h1>

    <h4>
      {{ title }} -
      <i>без применения фильтра</i>
    </h4>
    <h4>
      {{ title | lowercase }} -
      <i>применён локальный фильтр toLowerCase</i>
    </h4>
    <h4>
      {{ title | uppercase }} -
      <i>применён глобальный фильтр toUpperCase</i>
    </h4>
    <h4>{{ title | uppercase | lowercase }} применили два фильтра</h4>
    <hr>

    <h3>Фильтрация списка, введите буквы</h3>
    <input
      type="text"
      v-model="searchName"
    >
    <ul>
      <li
        v-for="name in filteredNames"
        :key="name"
      >
        {{ name }}
      </li>
    </ul>
    <hr>
  </div>
</template>

<script>
export default {
  name: "Filters",
  data() {
    return {
      title: "Под Заголовок Страницы",
      searchName: "",
      names: [
        "Vlad",
        "Max",
        "Elena",
        "Igor",
        "Piter",
        "Svan",
        "Vedot",
        "Patrick",
        "Sveta",
        "Klava"
      ]
    };
  },
  computed: {
    filteredNames() {
      return this.names.filter(name => {
        return name.toLowerCase().indexOf(this.searchName.toLowerCase()) != -1;
      });
    }
  },
  filters: {
    lowercase(value) {
      return value.toLowerCase();
    }
  }
};
</script>

<style scoped>
  li {
    display: inline-block;
    margin-right: 5px;
  }
</style>