<template>
  <div class="jcs-content">
    jcs-content
  </div>
</template>

<script>
export default {
  name: 'Jcscontent',
  components: {
  }
}
</script>
<style scoped>

</style>