<template>
  <div class="jcs-sidebar">
    jcs-sidebar
  </div>
</template>

<script>
export default {
  name: 'Jcssidebar',
  components: {
  }
}
</script>
<style scoped>

</style>