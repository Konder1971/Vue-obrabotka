<template>
  <g>
    <circle class="first" cx="3" cy="12" r="3" />
    <circle class="middle" cx="12" cy="12" r="3" />
    <circle class="last" cx="21" cy="12" r="3" />
  </g>
</template>